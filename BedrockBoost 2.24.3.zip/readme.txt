# BedrockBooster
This client boosts your FPS and makes your game smoother to play on!
Fixes multiple bugs regarding the performance of the bedrock client.
Fast efficient and stable. Fast updates and 24/7 support!


Step 1: Download the zip file and extract it.

Step 2: Turn off windows real time protection, it marks it as a virus just like it marks any client as one. Use this link to learn how to turn it off: 

https://support.microsoft.com/en-us/windows/turn-off-defender-antivirus-protection-in-windows-security-99e6004f-c54c-8509-773c-a4d776b77960

Step 3: Install the resource pack that comes with the client. 

Step 4: Click on the client and press launch. 

Step 5: Toggle all the modules by clicking them.

Step 6: Watch your fps skyrocket